# @zixcel/github-auth

GitHub OAuth Device Flowを、製品UI、HTTP transport、credential custodyから分離する
provider固有の認証Planです。利用者はAppを作成せず、配布者が一度だけ登録した公開
client IDを使います。SaaS側はclient IDとDevice Flow有効化だけです。

- 通信は注入されたtransportだけを使い、browserを開きません。
- client secret、App秘密鍵、callback serverを必要としません。
- access tokenは注入されたcustody portへ直接渡し、結果には含めません。
- `connection_ref`の発行・保管はCrowsi Credential Agentの責務です。
- HAT、Hatter、Coelaなどconsumer固有の概念を持ちません。
- Consumerは宣言されたplacementを実測し、利用不能を推測で補完しません。
- provider networkとCrowsi custodyが同じローカル配置で利用できる場合だけ開始します。

```js
import { githubAuthDeclaration, requestGitHubDeviceCode }
  from '@zixcel/github-auth'

const declaration = githubAuthDeclaration()
const attempt = await requestGitHubDeviceCode(declaration,
  { clientId: 'Iv23Public', nowUnixMs: Date.now() }, transport)
```
