import { TOOL_ID, validateDeclaration } from './declaration.mjs'
import { bounded, freeze, identifier, integer, invalid, opaque } from './validation.mjs'

export const ATTEMPT_SCHEMA = 'zixcel://github/oauth-device-attempt/v1'
const deviceUrl = 'https://github.com/login/device/code'
const tokenUrl = 'https://github.com/login/oauth/access_token'

export async function requestGitHubDeviceCode(declaration, input, transport) {
  validateDeclaration(declaration)
  const clientId = identifier(input?.clientId, 128, 'client-id')
  const nowUnixMs = integer(input?.nowUnixMs, 0, 'time')
  const response = await send(transport, deviceUrl, form({ client_id: clientId,
    scope: declaration.scopes.join(' ') }))
  return acceptGitHubDeviceCodeResponse(declaration, { clientId, nowUnixMs, response })
}

export function acceptGitHubDeviceCodeResponse(declaration, input) {
  validateDeclaration(declaration)
  const clientId = identifier(input?.clientId, 128, 'client-id')
  const now = integer(input?.nowUnixMs, 0, 'time')
  const wire = accepted(input?.response, 'device-code')
  const expiresIn = integer(wire.expires_in, 60, 'expires-in')
  const interval = integer(wire.interval ?? 5, 1, 'interval')
  if (expiresIn > 900 || interval > 60) invalid('provider-bounds')
  const verificationUri = exactVerificationUri(wire.verification_uri)
  return freeze({ schema: ATTEMPT_SCHEMA, providerId: 'github', toolId: TOOL_ID,
    clientId, deviceCode: opaque(wire.device_code, 16, 512, 'device-code'),
    userCode: bounded(wire.user_code, 4, 32, 'user-code'), verificationUri,
    expiresAtUnixMs: now + expiresIn * 1000,
    nextPollUnixMs: now + interval * 1000, intervalSeconds: interval })
}

export async function pollGitHubDeviceAuthorization(attempt, input, transport, custody) {
  validateAttempt(attempt)
  const now = integer(input?.nowUnixMs, 0, 'time')
  if (now > attempt.expiresAtUnixMs) invalid('attempt-expired')
  if (now < attempt.nextPollUnixMs) invalid('poll-early')
  const response = await send(transport, tokenUrl, form({ client_id: attempt.clientId,
    device_code: attempt.deviceCode,
    grant_type: 'urn:ietf:params:oauth:grant-type:device_code' }))
  const wire = accepted(response, 'token')
  if (wire.error) return pending(attempt, wire, now)
  const token = opaque(wire.access_token, 16, 4096, 'access-token')
  if (wire.token_type !== 'bearer' || typeof custody?.storeGitHubToken !== 'function') {
    invalid('custody')
  }
  const receipt = await custody.storeGitHubToken({ accessToken: token,
    scopes: exactScopes(wire.scope), tokenType: 'bearer' })
  return freeze({ status: 'connected', connectionRef:
    bounded(receipt?.connectionRef, 1, 256, 'connection-ref') })
}

function pending(attempt, wire, now) {
  if (wire.error === 'authorization_pending') return freeze({ status: 'pending',
    nextPollUnixMs: now + attempt.intervalSeconds * 1000 })
  if (wire.error === 'slow_down') return freeze({ status: 'pending',
    nextPollUnixMs: now + (attempt.intervalSeconds + 5) * 1000 })
  if (['access_denied', 'expired_token', 'incorrect_device_code'].includes(wire.error)) {
    invalid(wire.error)
  }
  invalid('provider-response')
}
function validateAttempt(value) {
  if (!value || value.schema !== ATTEMPT_SCHEMA || value.providerId !== 'github'
    || value.toolId !== TOOL_ID) invalid('attempt')
  identifier(value.clientId, 128, 'client-id'); opaque(value.deviceCode, 16, 512, 'device-code')
  bounded(value.userCode, 4, 32, 'user-code'); exactVerificationUri(value.verificationUri)
  integer(value.expiresAtUnixMs, 0, 'expires'); integer(value.nextPollUnixMs, 0, 'poll')
  integer(value.intervalSeconds, 1, 'interval')
}
async function send(transport, url, body) {
  if (typeof transport?.send !== 'function') invalid('transport')
  return transport.send({ method: 'POST', url,
    headers: { accept: 'application/json', 'content-type': 'application/x-www-form-urlencoded' },
    body, maximumResponseBytes: 16_384 })
}
function accepted(response, code) {
  if (response?.status !== 200 || typeof response.body !== 'string'
    || response.body.length > 16_384) invalid(code)
  try { return JSON.parse(response.body) } catch { invalid(code) }
}
function form(values) { return new URLSearchParams(values).toString() }
function exactVerificationUri(value) {
  if (value !== 'https://github.com/login/device') invalid('verification-uri')
  return value
}
function exactScopes(value) {
  const scopes = typeof value === 'string' ? value.split(/[ ,]+/u).filter(Boolean) : []
  const expected = ['repo', 'workflow', 'read:org']
  if (scopes.length !== expected.length || new Set(scopes).size !== expected.length
    || expected.some(scope => !scopes.includes(scope))) invalid('scope')
  return expected
}
